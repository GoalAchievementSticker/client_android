package com.example.java_sticker;

public class UserRegister {
    public String userName; //사용자 이름
    public String profileImageUrl; //사용자 프로필사진
    public String uid; //로그인한 사용자 고유아이디
}
